# Kota Emas Ventures — Construction Control Demo

A standalone, responsive HTML prototype for a construction management dashboard.

## How to run
1. Extract the ZIP if you downloaded the package.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox).
3. Use the left navigation to explore Overview, Project Control, Cost & Cash Flow, Claims & Payments, Site Operations, and Tender & Documents.
4. Try Add project / Add claim and Export CSV.

## Important
- All names, projects, financial figures, statuses and dates are fictional demo data.
- This prototype runs locally in the browser. It has no database, authentication, cloud sync, or production security.
- New records are held only in the current page session and are not saved to a server.
- Before a real deployment, confirm the company's workflows and requirements, replace sample data, add access control and backend storage, and test financial calculations.
